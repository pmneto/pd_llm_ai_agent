# app.py
import streamlit as st
from dotenv import load_dotenv

load_dotenv()

from agents.wine_agent import build_agent


def main():
    st.set_page_config(page_title="CariocaWine", page_icon="🍷")
    st.title("🍷 CariocaWine - Seu Sommelier Digital")
    
    query = st.text_input("O que deseja saber sobre vinhos, harmonizações ou onde comprar?")

    if query:
        with st.spinner("Buscando informações..."):
            agent = build_agent()
            resposta = agent.invoke({"input": query})
        st.success("Resultado:")
        st.write(resposta)

if __name__ == "__main__":
    main()
